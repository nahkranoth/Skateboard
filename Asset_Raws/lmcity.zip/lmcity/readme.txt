LMcity_1

Environment map by: John Staats.

Instructions: Unzip to your Quake2 folder making sure you
              recurse subdirectories.

Description:  City at night.

	Mr. White
	jkeffer@ilap.com

